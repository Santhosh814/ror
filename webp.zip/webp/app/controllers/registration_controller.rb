class RegistrationController < ApplicationController

 def index
    @reg =Reg.all
 end

def next1
@student=Student.all
end

 def new
 @courses=Course.all
 @students=Student.all
 end



  def show
      id=params[:id1]
     @reg = Reg.where("student_id = ?", id)
  end
  
 def create
  @reg = Reg.new(book_params)
      if @reg.save
         redirect_to :action => 'show',:id1 => @reg.student_id 
      else
          @courses=Course.all
          @students=Student.all
         render :action => 'new'
      end
  end
 


  def show1
   
     @reg = Reg.find(student_params)
  end
  

def delete
        @reg=Reg.find(params[:id])
          if @reg.destroy
              redirect_to :action => 'index';
	else
             render 'new'
    end 
 end



 def student_params
 params.require(:books).permit(:student_id)
 end



   def book_params
      params.require(:books).permit(:course_id,:student_id)
   end
end
