class Course < ApplicationRecord
  belongs_to :regs
end
