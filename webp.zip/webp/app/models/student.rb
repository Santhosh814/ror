class Student < ApplicationRecord
 belongs_to :regs
end
