Rails.application.routes.draw do
  root 'registration#index'

  get 'registration/new'

  post 'registration/create'

  get 'registration/show'
post 'registration/show1'

  get 'registration/delete'
get 'registration/next1'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
