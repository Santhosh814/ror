class CreateCourses < ActiveRecord::Migration[5.0]
  def change
    create_table :courses do |t|
         t.column :Course_name, :string, :limit => 32, :null => false
      end
        Course.create :Course_name => "WEBP"
	Course.create :Course_name => "DATA MINING"
        Course.create :Course_name => "DBMS"
        Course.create :Course_name => "DAA"
        Course.create :Course_name => "NETWORKS"
      
   end

   def self.down
      drop_table :courses
   end
end
