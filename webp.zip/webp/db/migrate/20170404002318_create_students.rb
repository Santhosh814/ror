class CreateStudents < ActiveRecord::Migration[5.0]
  def change
    create_table :students do |t|
         t.column :Name, :string, :limit => 32, :null => false
       
      end
          Student.create :Name => "manoj"
          Student.create :Name => "jashwanth"
          Student.create :Name => "phani"
          Student.create :Name => "jafar"
          Student.create :Name => "jaga"
          Student.create :Name => "haranath"
          Student.create :Name => "prashanth"
          Student.create :Name => "surya"
   end

   def self.down
      drop_table :students
   end
end
