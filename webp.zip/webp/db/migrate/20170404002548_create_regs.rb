class CreateRegs < ActiveRecord::Migration[5.0]
  def change
    create_table :regs do |t|
     
         t.references :course, foreign_key: true
         t.references :student,foreign_key:true
      end
   end

   def self.down
      drop_table :regs
   end
end
